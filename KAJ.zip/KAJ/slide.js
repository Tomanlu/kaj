class Slide{
	constructor(contentType){
		this.content = "";
		this.contentType = contentType;
		this.backgroundType = BackgroundType.color;
		this.background = "#ffffff";
	}
}

const BackgroundType = {
	color: 0,
	backgroundImage: 1,
}

const ContenType = {
	textContent: 0,
	drawContent: 1,
}