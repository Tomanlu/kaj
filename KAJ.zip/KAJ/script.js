$(document.documentElement).ready(() =>{
	var editorPP = new Editor();
})
class Editor{
	constructor(){
			this.slidePattern = '<li class="item m-1 d-flex align-items-center justify-content-center"><div class="slide preview col-11 shadow rounded"><div class="slide-content">';			  
		
			this.slides = [];
			this.currentSlideIndex = 0;
			this.slidesList = $("#slides-list");
			
			this.quillInit = new QuillInit();
			this.initHanlders();
			this.addSlide();			
		}
	
	addSlide(){
		this.slides.push(new Slide())
		const slide = $(this.slidePattern);
		slide.on("click", (e) => {
			this.selectSlide(e);
		});
		$("#slides-list").append(slide);
		this.currentSlideIndex = this.slides.length - 1;
		this.setSelectedSlide();
	}
	
	deleteSlide(){
		this.slides.splice(this.currentSlideIndex, 1);
		$("#slides-list").find("li")[this.currentSlideIndex].remove();
		this.currentSlideIndex = this.currentSlideIndex < this.slides.length ? this.currentSlideIndex : this.slides.length - 1;
		this.setSelectedSlide();
	}
	
	initHanlders(){
		$("#slides-list").sortable({
			start: (event, ui) => {
				const start_pos = ui.item.index();
				ui.item.data('start_pos', start_pos);
			},
			update: (event, ui) => {
				const start_pos = ui.item.data('start_pos');
				const end_pos = ui.item.index();
				this.moveItem(start_pos, end_pos);
			}
		});
		
		$("#new-slide").on("click", this.addSlide.bind(this))
		$("#delete-slide").on("click", this.deleteSlide.bind(this))
		this.quillInit.quill.on('text-change', (delta, oldDelta, source) => {
				this.slides[this.currentSlideIndex].content = this.quillInit.getContent();
				$("#slides-list li .slide-content")[this.currentSlideIndex].innerHTML = this.quillInit.getContent();
		});
  
		$("#slides-list").find("li").on("click", (e) => {
			this.selectSlide(e);
		})

		$("#start-presentation").on("click", (e) =>{
			$("#fullscreen").removeClass("d-none");
			this.toggleFullScreen();
			this.currentFullscreenIndex = 0;
			this.setBackground(this.slides[this.currentFullscreenIndex], $("#fullscreen"))
			$("#fullscreen").html(this.slides[this.currentFullscreenIndex].content);
			
			$(document.documentElement).on("keyup", (e) =>{
				if(e.originalEvent.code === "ArrowLeft"){
					if(this.currentFullscreenIndex > 0){
					this.currentFullscreenIndex--;
					$("#fullscreen").html(this.slides[this.currentFullscreenIndex].content);
					this.setBackground(this.slides[this.currentFullscreenIndex], $("#fullscreen"))			
					}
				}else if(e.originalEvent.code === "ArrowRight"){
					if(this.currentFullscreenIndex < this.slides.length - 1){
					this.currentFullscreenIndex++;
					$("#fullscreen").html(this.slides[this.currentFullscreenIndex].content);
					this.setBackground(this.slides[this.currentFullscreenIndex], $("#fullscreen"))			
					}
				}
			});
			$(document.documentElement).on("webkitfullscreenchange mozfullscreenchange fullscreenchange", (e) => {
				if(!document.fullScreen && !document.mozFullScreen && !document.webkitIsFullScreen){
					$(document.documentElement).off("keyup");
					$(document.documentElement).off("webkitfullscreenchange mozfullscreenchange fullscreenchange");
					$("#fullscreen").addClass("d-none");
				}
			});
		})
		
		$("#background-color").on("change", (e) =>{
			this.slides[this.currentSlideIndex].background = $("#background-color").val();
			this.slides[this.currentSlideIndex].backgroundType = BackgroundType.color;
			const t = $("#slides-list").find("li")[this.currentSlideIndex];
			
			$(t).find("div.slide").css("background-color", this.slides[this.currentSlideIndex].background);
			$("#view").css("background-color", this.slides[this.currentSlideIndex].background);
		});
		
		$("#background-image").change((e) => {
			this.readURL(e.target);
		});
		
		$(".nav-link").on("click", (e) => {
			$(".nav-link").removeClass("active");
		});
	}
	
	moveItem(oldIndex, newIndex) {
		this.slides.splice(newIndex, 0, this.slides.splice(oldIndex, 1)[0]);
		if(oldIndex > this.currentSlideIndex && newIndex <= this.currentSlideIndex){
			this.currentSlideIndex++;
		}else if(oldIndex < this.currentSlideIndex && newIndex >= this.currentSlideIndex){
			this.currentSlideIndex--;
		}else if(this.currentSlideIndex === oldIndex){
			this.currentSlideIndex = newIndex;
		}
	};
	
	selectSlide(e){
		this.currentSlideIndex = $("#slides-list").find("li").index(e.currentTarget);
		this.setSelectedSlide();
	}
	
	setSelectedSlide(){
		if(this.slides.length == 0) return;
		$("#slides-list").find("li").removeClass("active");
		$("#slides-list").find("li:nth-child(" + (this.currentSlideIndex + 1) + ")").addClass("active");
		this.quillInit.setContent(this.slides[this.currentSlideIndex].content);
		this.setBackground(this.slides[this.currentSlideIndex], $("#view"));
		$("#image-error").addClass("d-none");
	}
	
	setBackground(slide, container){
		switch(slide.backgroundType){
			case BackgroundType.color:
				container.css("background-color", slide.background);
				container.css("background-image", "");
				$("#background-color").val(slide.background);
				break;
			case BackgroundType.backgroundImage:
				container.css("background-color", "");
				container.css("background-image", slide.background);		
				break;
				
		}
	}
	
	readURL(input) {
	  if (input.files && input.files[0]) {
			$("#image-error").addClass("d-none");
		if(!this.isImage(input.files[0])) {
			$("#image-error").removeClass("d-none");
			$("#background-image").val("");
			return;			
		}
		
		var reader = new FileReader();
		const selectedSlideIndex = this.currentSlideIndex;
		reader.onload = (e) => {
			const tmp = $("#slides-list").find("li")[selectedSlideIndex];			
			$(tmp).find("div.slide").css("background-image", 'url("' + reader.result + '")');
			$("#view").css("background-image", 'url("' + reader.result + '")');
			this.slides[selectedSlideIndex].background = 'url("' + reader.result + '")';
			this.slides[selectedSlideIndex].backgroundType = BackgroundType.backgroundImage;
			this.setBackground(this.slides[selectedSlideIndex], $("#view"))
			$("#background-image").val("");		
		}
		
		reader.readAsDataURL(input.files[0]);
	  }
	}
	
	isImage(file){
		return file.type.includes("image");
	}
	
	toggleFullScreen() {
	  if (!document.fullscreenElement &&    // alternative standard method
		  !document.mozFullScreenElement && !document.webkitFullscreenElement && !document.msFullscreenElement ) {  // current working methods
		if (document.documentElement.requestFullscreen) {
		  document.querySelector("#fullscreen").requestFullscreen();
		} else if (document.documentElement.msRequestFullscreen) {
		  document.querySelector("#fullscreen").msRequestFullscreen();
		} else if (document.documentElement.mozRequestFullScreen) {
		  document.querySelector("#fullscreen").mozRequestFullScreen();
		} else if (document.documentElement.webkitRequestFullscreen) {
		  document.querySelector("#fullscreen").webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
		}
	  } else {
		if (document.exitFullscreen) {
		  document.exitFullscreen();
		} else if (document.msExitFullscreen) {
		  document.msExitFullscreen();
		} else if (document.mozCancelFullScreen) {
		  document.mozCancelFullScreen();
		} else if (document.webkitExitFullscreen) {
		  document.webkitExitFullscreen();
		}
	  }
	}
}
